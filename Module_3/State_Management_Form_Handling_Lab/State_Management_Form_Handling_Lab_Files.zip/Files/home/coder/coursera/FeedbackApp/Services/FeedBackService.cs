using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.JSInterop;

namespace FeedbackApp
{
    public class FeedbackService
    {
        private readonly IJSRuntime jsRuntime;
        
        public FeedbackService(IJSRuntime jSRuntime)
        {
            this.jsRuntime = jsRuntime;
        }

        public async Task SaveFeedbackAsync(List<Feedback> feedbackList)
        {
            var json = JsonSerializer.Serialize(feedbackList);
            await jsRuntime.InvokeVoidAsync("localStorage.setItem", "feedback", json);
        }

        public async Task<List<Feedback>> LoadFeedbackAsync()
        {
            var json = await jsRuntime.InvokeAsync<string>("localStorage.getItem", "feedback");
            return string.IsNullOrEmpty(json) ? new List<Feedback>() : JsonSerializer.Deserialize<List<Feedback>>(json) ?? new List<Feedback>();
        }
    }
}