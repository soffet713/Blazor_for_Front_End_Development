using System.Linq.Expressions;
using Microsoft.AspNetCore.SignalR;

public class NotificationHub : Hub
{
    public async Task SendMessage(string user, string message)
    {
        try
        {
             await Clients.All.SendAsync("ReceiveMessage",user,message);
        }
        catch(Exception e)
        {
            Console.WriteLine($"Error:{e.Message}");
        }
       
    }
    
}